Arise Pose Driver Tool
For Maya 2023+

Installation and Launch:

1. Copy the Python file to your Maya scripts folder:

C:\Users\YourUserName\Documents\maya\YourMayaVersion\scripts

Example:

C:\Users\YourUserName\Documents\maya\2025\scripts

2. Restart Maya.

3. Open the Maya Python Script Editor and run:

import importlib, ArisePoseDriver as m
importlib.reload(m)
m.show_ui()

Compatibility:

Maya 2023+
