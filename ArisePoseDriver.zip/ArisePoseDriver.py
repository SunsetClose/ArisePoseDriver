# -*- coding: utf-8 -*-

from __future__ import annotations
import sys
import re
from maya import cmds, mel
from maya.OpenMayaUI import MQtUtil

try:
    from PySide6 import QtCore, QtGui, QtWidgets
    from shiboken6 import wrapInstance
    QT_MAJOR = 6
except Exception:
    from PySide2 import QtCore, QtGui, QtWidgets
    from shiboken2 import wrapInstance
    QT_MAJOR = 5

# Cross-version aliases
ActionClass = QtGui.QAction if QT_MAJOR >= 6 else QtWidgets.QAction
ShortcutClass = QtGui.QShortcut if QT_MAJOR >= 6 else QtWidgets.QShortcut
KeySequence = QtGui.QKeySequence

# -------------------------
# Shiboken wrap helper
# -------------------------
def _wrap_instance(ptr):
    if not ptr:
        return None
    if QT_MAJOR >= 6:
        import shiboken6 as sb
    else:
        import shiboken2 as sb
    return sb.wrapInstance(int(ptr), QtWidgets.QWidget)

def maya_main_window():
    return _wrap_instance(MQtUtil.mainWindow())

# -------------------------
# General helpers
# -------------------------
def info_msg(text, ms=1800):
    try:
        cmds.inViewMessage(amg=f"<hl>{text}</hl>", pos="midCenter", fst=300, fade=True, bkc=0x222222, alpha=0.9)
    except Exception:
        cmds.warning(text)

def undo_chunk(func):
    def _wrap(*args, **kwargs):
        try:
            cmds.undoInfo(openChunk=True)
            return func(*args, **kwargs)
        finally:
            cmds.undoInfo(closeChunk=True)

    return _wrap

def mirror_name(name):
    """Return the right-side counterpart name from a left-side node name."""
    if name is None:
        return None
    if name.startswith("L_"):
        return name.replace("L_", "R_", 1)
    if name.endswith("_L"):
        return name.replace("_L", "_R")
    if "_L_" in name:
        return name.replace("_L_", "_R_")
    return name

# =========================
# AriseSec Core Operations
# =========================
class AriseSecOps(object):
    def __init__(self):
        self.namestring = {}

    # --------------- BlendShape ---------------

    @undo_chunk
    def create_blendshape(self):
        model = self.namestring.get(1)
        if not model or not cmds.objExists(model):
            raise RuntimeError("Please load a valid model first.")
        bs_node = f"{model}BS"
        if cmds.objExists(bs_node):
            info_msg(f"BlendShape already exists: {bs_node}")
            return
        cmds.blendShape(model, n=bs_node, at=True, foc=True)
        info_msg(f"BlendShape created: {bs_node}")

    @undo_chunk
    def rename_blendshape(self):
        model = self.namestring.get(1)
        if not model or not cmds.objExists(model):
            raise RuntimeError("Please load a valid model first.")
        bs_node = f"{model}BS"
        for node in cmds.listHistory(model) or []:
            if cmds.nodeType(node) == "blendShape":
                cmds.rename(node, bs_node)
                info_msg(f"BlendShape renamed to: {bs_node}")
                return
        raise RuntimeError(f"No BlendShape node found in the history of {model}.")

    @undo_chunk
    def transfer_selected_targets(self):
        """Transfer selected ChannelBox BlendShape targets to the current model BlendShape node."""
        model = self.namestring.get(1)
        if not model or not cmds.objExists(model):
            raise RuntimeError("Please load a valid model first.")
        try:
            bs_attrs = mel.eval("channelBox -q -selectedHistoryAttributes $gChannelBoxName")
        except Exception:
            bs_attrs = None
        sel = cmds.ls(sl=True)
        if not sel or not bs_attrs:
            raise RuntimeError("Select a mesh with BlendShape targets and select target attributes in the ChannelBox.")
        source_bs = None
        for node in cmds.listHistory(sel[0]) or []:
            if cmds.nodeType(node) == "blendShape":
                source_bs = node
                break
        if not source_bs:
            raise RuntimeError("No BlendShape node found on the selected object.")
        created = []
        for bs_name in bs_attrs:
            dup = cmds.duplicate(model, n=bs_name, rr=True)[0]
            created.append(dup)
        bs_node = f"{model}BS"
        if not cmds.objExists(bs_node):
            cmds.blendShape(model, n=bs_node, foc=True)
        count = cmds.blendShape(bs_node, q=True, weightCount=True) or 0
        for i, target in enumerate(created):
            cmds.blendShape(bs_node, e=True, t=(model, count + i, target, 1.0))
            cmds.delete(target)
        info_msg(f"Transferred {len(created)} targets.")

    # --------------- Arm / Leg Drive ---------------

    @undo_chunk
    def create_arm_drive(self):
        need = [1, 2, 3, 4, 5]
        for i in need:
            if not self.namestring.get(i) or not cmds.objExists(self.namestring[i]):
                raise RuntimeError(
                    f"Arm setup item {i} is missing. Check Model, Arm Base, Arm Root, Arm Mid, and Arm Tip.")
        _create_driven_ball_arisesec_impl(self.namestring, opt=2)
        info_msg("Arm drive created.")

    @undo_chunk
    def create_leg_drive(self):
        need = [1, 6, 7, 8, 9, 10]
        for i in need:
            if not self.namestring.get(i) or not cmds.objExists(self.namestring[i]):
                raise RuntimeError(
                    f"Leg setup item {i} is missing. Check Model, Leg Base, Leg Root, Leg Mid, Leg Tip, and Toes Root.")
        _create_driven_ball_arisesec_impl(self.namestring, opt=3)
        info_msg("Leg drive created.")

    # --------------- Fingers ---------------

    @undo_chunk
    def create_fingers_drive(self, fingers_left_triplets: dict):
        """
        Create finger BlendShape targets and driven keys.

        fingers_left_triplets:
            key: Thumb, Index, Middle, Ring, Pinky
            value: left-side joint triplet, such as (j1, j2, j3)

        The right side is derived through mirror_name().
        """
        model = self.namestring.get(1)
        if not model or not cmds.objExists(model):
            raise RuntimeError("Please load a valid model first.")
        left_order = ["Thumb", "Index", "Middle", "Ring", "Pinky"]
        left = []
        for key in left_order:
            j1, j2, j3 = fingers_left_triplets[key]
            for joint in (j1, j2, j3):
                if not joint or not cmds.objExists(joint):
                    raise RuntimeError(f"Missing finger joint: {joint} in {key}.")
            left += [j1, j2, j3]
        right = [mirror_name(node) for node in left]
        all_jnts = left + right

        listBSName_L = [
            "Thumb1_L", "Thumb2_L", "Thumb3_L",
            "Index1_L", "Index2_L", "Index3_L",
            "Middle1_L", "Middle2_L", "Middle3_L",
            "Ring1_L", "Ring2_L", "Ring3_L",
            "Pinky1_L", "Pinky2_L", "Pinky3_L",
        ]
        listBSName_R = [name.replace("_L", "_R") for name in listBSName_L]
        listBSName = listBSName_L + listBSName_R

        bs_node = f"{model}BS"
        if not cmds.objExists(bs_node):
            cmds.blendShape(model, n=bs_node, foc=True)
        created = []
        for bs_name in listBSName:
            created.append(cmds.duplicate(model, n=bs_name, rr=True)[0])
        base_count = cmds.blendShape(bs_node, q=True, weightCount=True) or 0
        for i, target in enumerate(created):
            cmds.blendShape(bs_node, e=True, t=(model, base_count + i, target, 1.0))
            cmds.delete(target)
        for i, bs_name in enumerate(listBSName):
            drv_attr = f"{all_jnts[i]}.rotateZ"
            cmds.setDrivenKeyframe(f"{bs_node}.{bs_name}", cd=drv_attr, driverValue=0, value=0, itt="linear",
                                   ott="linear")
            cmds.setDrivenKeyframe(f"{bs_node}.{bs_name}", cd=drv_attr, driverValue=90, value=1, itt="linear",
                                   ott="linear")

        info_msg("Finger drive created.")

    @staticmethod
    def finger_bs_to_joint_map_left():
        return {
            "Thumb1_L": "L_Fingers_thumb_0_0_jnt",
            "Thumb2_L": "L_Fingers_thumb_0_1_jnt",
            "Thumb3_L": "L_Fingers_thumb_0_2_jnt",
            "Index1_L": "L_Fingers_finger_0_1_jnt",
            "Index2_L": "L_Fingers_finger_0_2_jnt",
            "Index3_L": "L_Fingers_finger_0_3_jnt",
            "Middle1_L": "L_Fingers_finger_1_1_jnt",
            "Middle2_L": "L_Fingers_finger_1_2_jnt",
            "Middle3_L": "L_Fingers_finger_1_3_jnt",
            "Ring1_L": "L_Fingers_finger_2_1_jnt",
            "Ring2_L": "L_Fingers_finger_2_2_jnt",
            "Ring3_L": "L_Fingers_finger_2_3_jnt",
            "Pinky1_L": "L_Fingers_finger_3_1_jnt",
            "Pinky2_L": "L_Fingers_finger_3_2_jnt",
            "Pinky3_L": "L_Fingers_finger_3_3_jnt",
        }

    @undo_chunk
    def update_pose_finger(self, bs_name: str, mirror: bool):
        model = self.namestring.get(1)
        if not model or not cmds.objExists(model):
            raise RuntimeError("Please load a valid model first.")
        mapping = self.finger_bs_to_joint_map_left()
        if bs_name not in mapping:
            raise RuntimeError(f"Unknown finger target: {bs_name}")
        joint = mapping[bs_name]
        if not cmds.objExists(joint):
            raise RuntimeError(f"Finger joint not found: {joint}")
        bs_node = f"{model}BS"
        if not cmds.objExists(bs_node):
            raise RuntimeError(f"BlendShape node not found: {bs_node}")
        dv = cmds.getAttr(f"{joint}.rotateZ")
        try:
            cmds.keyframe(f"{bs_node}.{bs_name}", e=True, absolute=True, option="over", index=(1, 1), floatChange=dv)
        except Exception:
            cmds.setAttr(f"{bs_node}.{bs_name}", dv)
        if mirror:
            bs_r = bs_name.replace("_L", "_R")
            try:
                cmds.keyframe(f"{bs_node}.{bs_r}", e=True, absolute=True, option="over", index=(1, 1), floatChange=dv)
            except Exception:
                cmds.setAttr(f"{bs_node}.{bs_r}", dv)

        info_msg(f"Finger UpdatePose: {bs_name} -> {dv:.2f}")

    # --------------- UpdatePose 四肢 ---------------

    @undo_chunk
    def update_pose_joint(self, label, target_item, mirror_on):
        """
        Update Arise limb pose-reader driven keys.

        The function writes driven keys to the custom attributes on the
        corresponding left/right DriGrp nodes.

        target_item examples:
            L_Arm_root_jnt_Up
            L_Leg_mid_jnt_FrontUp
        """
        mapping = {
            "Arm Base": 11,
            "Arm Root": 12,
            "Arm Mid": 13,
            "Arm Tip": 14,
            "Leg Base": 15,
            "Leg Root": 16,
            "Leg Mid": 17,
            "Leg Tip": 18,
        }

        label_to_joint = {
            "Arm Base": "L_Arm_base_jnt",
            "Arm Root": "L_Arm_root_jnt",
            "Arm Mid": "L_Arm_mid_jnt",
            "Arm Tip": "L_Arm_tip_jnt",
            "Leg Base": "L_Leg_base_jnt",
            "Leg Root": "L_Leg_root_jnt",
            "Leg Mid": "L_Leg_mid_jnt",
            "Leg Tip": "L_Leg_tip_jnt",
        }

        idx = mapping.get(label)
        ctlL = self.namestring.get(idx)
        joint_label = label_to_joint.get(label)

        if not ctlL:
            raise RuntimeError(f"Please load the FK controller for {label}.")

        if not joint_label:
            raise RuntimeError(f"Unknown Arise limb label: {label}")

        if not cmds.objExists(ctlL):
            raise RuntimeError(f"Left FK controller not found: {ctlL}")

        drive_grp = f"{joint_label}_DriGrp"
        direction_loc = f"{joint_label}_direction"
        angle_attr = f"{target_item}_angle.angle"
        drive_attr = f"{drive_grp}.{target_item}"

        if not cmds.objExists(drive_grp):
            raise RuntimeError(f"Left drive group not found: {drive_grp}")

        if not cmds.objExists(direction_loc):
            raise RuntimeError(f"Left direction locator not found: {direction_loc}")

        if not cmds.objExists(target_item):
            raise RuntimeError(f"Left target locator not found: {target_item}")

        rot = cmds.getAttr(f"{ctlL}.rotate")[0]

        try:
            cmds.delete(cmds.pointConstraint(direction_loc, target_item, mo=0))
        except Exception:
            pass

        cmds.setDrivenKeyframe(
            drive_attr,
            driverValue=0,
            cd=angle_attr,
            value=1,
            ott="linear",
            itt="linear"
        )

        cmds.setAttr(f"{ctlL}.rotate", 0, 0, 0, type="double3")

        base = target_item.replace(joint_label, "")
        primary_dirs = ["_Up", "_Dn", "_Front", "_Back"]

        if base in primary_dirs:
            dv = cmds.getAttr(f"{target_item}_angle.axisAngle.angle")
        else:
            dv = 45

        cmds.keyframe(
            drive_attr,
            e=True,
            absolute=True,
            option="over",
            index=(1, 1),
            floatChange=dv
        )

        cmds.setAttr(f"{ctlL}.rotate", rot[0], rot[1], rot[2], type="double3")

        if mirror_on:
            joint_label_r = mirror_name(joint_label)
            ctlR = mirror_name(ctlL)
            targetR = mirror_name(target_item)

            drive_grp_r = f"{joint_label_r}_DriGrp"
            direction_loc_r = f"{joint_label_r}_direction"
            angle_attr_r = f"{targetR}_angle.angle"
            drive_attr_r = f"{drive_grp_r}.{targetR}"

            if not cmds.objExists(ctlR):
                raise RuntimeError(f"Right FK controller not found: {ctlR}")

            if not cmds.objExists(drive_grp_r):
                raise RuntimeError(f"Right drive group not found: {drive_grp_r}")

            if not cmds.objExists(direction_loc_r):
                raise RuntimeError(f"Right direction locator not found: {direction_loc_r}")

            if not cmds.objExists(targetR):
                raise RuntimeError(f"Right target locator not found: {targetR}")

            cmds.setAttr(f"{ctlR}.rotate", rot[0], rot[1], rot[2], type="double3")

            try:
                cmds.delete(cmds.pointConstraint(direction_loc_r, targetR, mo=0))
            except Exception:
                pass

            cmds.setDrivenKeyframe(
                drive_attr_r,
                driverValue=0,
                cd=angle_attr_r,
                value=1,
                ott="linear",
                itt="linear"
            )

            cmds.setAttr(f"{ctlR}.rotate", 0, 0, 0, type="double3")

            base_r = targetR.replace(joint_label_r, "")
            if base_r in primary_dirs:
                dv2 = cmds.getAttr(f"{targetR}_angle.axisAngle.angle")
            else:
                dv2 = 45

            cmds.keyframe(
                drive_attr_r,
                e=True,
                absolute=True,
                option="over",
                index=(1, 1),
                floatChange=dv2
            )

            cmds.setAttr(f"{ctlR}.rotate", rot[0], rot[1], rot[2], type="double3")

        info_msg(f"UpdatePose updated: {label} -> {target_item}")

    # --------------- Neck ---------------

    @undo_chunk
    def create_neck_drive(self):
        need = [1, 19, 20, 21]
        for i in need:
            if not self.namestring.get(i) or not cmds.objExists(self.namestring[i]):
                raise RuntimeError(f"Neck setup item {i} is missing. Check Model, Select Joint, Parent, and Child.")

        _create_neck_drive_impl(self.namestring)
        info_msg("Neck drive created.")

    @undo_chunk
    def update_pose_neck(self, target_attr: str):
        """
        Update a neck pose-reader driven key.

        target_attr example:
            M_Neck_head_jnt_Up
        """
        joint = self.namestring.get(19)
        ctrl = self.namestring.get(22)
        model = self.namestring.get(1)
        if not joint or not cmds.objExists(joint):
            raise RuntimeError("Please load a valid neck joint.")
        if not ctrl or not cmds.objExists(ctrl):
            raise RuntimeError("Please load a valid neck FK controller.")
        bs_node = f"{model}BS"
        if not model or not cmds.objExists(bs_node):
            raise RuntimeError(f"BlendShape node not found: {bs_node}")
        rot = cmds.getAttr(f"{ctrl}.rotate")[0]
        direction_suffix = None
        for suffix in ["_Up", "_Dn", "_Front", "_Back", "_FrontUp", "_FrontDn", "_BackUp", "_BackDn"]:
            if target_attr.endswith(suffix):
                direction_suffix = suffix
                break
        if not direction_suffix:
            raise RuntimeError(f"Unknown neck direction target: {target_attr}")
        drive_grp = f"{joint}_DriveGrp"
        drive_attr = f"{drive_grp}.{joint}{direction_suffix}"
        angle_loc = f"{joint}{direction_suffix}"
        angle_attr = f"{angle_loc}_angle.angle"
        if not cmds.objExists(drive_grp):
            raise RuntimeError(f"Neck drive group not found: {drive_grp}")
        if not cmds.objExists(angle_loc):
            raise RuntimeError(f"Neck direction locator not found: {angle_loc}")
        try:
            constraint = cmds.pointConstraint(f"{joint}_direction", target_attr, mo=0)
            if constraint:
                cmds.delete(constraint)
        except Exception:
            pass
        cmds.setDrivenKeyframe(
            drive_attr,
            driverValue=0,
            cd=angle_attr,
            value=1,
            ott="linear",
            itt="linear"
        )
        cmds.setAttr(f"{ctrl}.rotate", 0, 0, 0, type="double3")
        if direction_suffix in ["_Up", "_Dn", "_Front", "_Back"]:
            try:
                dv = cmds.getAttr(f"{angle_loc}_angle.axisAngle.angle")
            except Exception:
                dv = 90
        else:
            dv = 45
        cmds.keyframe(
            drive_attr,
            e=True,
            absolute=True,
            option="over",
            index=(1, 1),
            floatChange=dv
        )

        cmds.setAttr(f"{ctrl}.rotate", rot[0], rot[1], rot[2], type="double3")
        info_msg(f"Neck UpdatePose completed: {target_attr} -> angle {dv:.2f}")


# AriseSec implementations (drive creators)
# -----------------------------------------
def _create_driven_ball_arisesec_impl(namestring: dict, opt: int):
    """
    Create AriseSec pose-reader drive setup.

    opt:
        2: Arm
        3: Leg
    """
    model = namestring.get(1)
    if not model or not cmds.objExists(model):
        raise RuntimeError("Please load a valid model first.")
    if not cmds.objExists(ARISE_DRIVE_GRP):
        cmds.group(em=True, name=ARISE_DRIVE_GRP)
    if opt == 2:
        JointName = [
            "L_Arm_base_jnt",
            "L_Arm_root_jnt",
            "L_Arm_mid_jnt",
            "L_Arm_tip_jnt",
            "R_Arm_base_jnt",
            "R_Arm_root_jnt",
            "R_Arm_mid_jnt",
            "R_Arm_tip_jnt",
        ]

        wristL = namestring[5]
        wristR = mirror_name(wristL)

        duL = cmds.joint(n=f"{wristL}_vec")
        cmds.delete(cmds.parentConstraint(wristL, duL, mo=0))
        cmds.parent(duL, wristL)

        duR = cmds.joint(n=f"{wristR}_vec")
        grpR = cmds.group(duR, n=f"{duR}_Grp")
        cmds.delete(cmds.parentConstraint(wristR, grpR, mo=0))
        cmds.parent(grpR, wristR)

        for attr in ("rx", "ry", "rz"):
            cmds.setAttr(f"{grpR}.{attr}", 0)
        for attr in ("sx", "sy", "sz"):
            cmds.setAttr(f"{grpR}.{attr}", 1)
        for dum in (duL, duR):
            source_wrist = wristL if dum == duL else wristR
            if cmds.getAttr(f"{source_wrist}.ty") != 0:
                cmds.setAttr(f"{dum}.ty", 1)

        AllL = [namestring[2], namestring[3], namestring[4], namestring[5], duL]
        AllR = [mirror_name(node) for node in AllL]
        AllJ = AllL + AllR
        setL = AllL[0:4]
        setR = AllR[0:4]
        AllSet = setL + setR

    elif opt == 3:
        JointName = [
            "L_Leg_base_jnt",
            "L_Leg_root_jnt",
            "L_Leg_mid_jnt",
            "L_Leg_tip_jnt",
            "R_Leg_base_jnt",
            "R_Leg_root_jnt",
            "R_Leg_mid_jnt",
            "R_Leg_tip_jnt",
        ]

        AllL = [namestring[6], namestring[7], namestring[8], namestring[9], namestring[10]]
        AllR = [mirror_name(node) for node in AllL]

        AllJ = AllL + AllR
        setL = AllL[0:4]
        setR = AllR[0:4]
        AllSet = setL + setR

    else:
        raise RuntimeError(f"Unsupported drive option: {opt}")

    AllAng = []
    vecNames = [
        "_Up", "_Dn", "_Front", "_Back",
        "_FrontUp", "_FrontDn", "_BackUp", "_BackDn",
        "_direction", "_position"
    ]
    vecPos = [
        [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1],
        [0, 0.6, 0.6], [0, -0.6, 0.6], [0, 0.6, -0.6], [0, -0.6, -0.6],
        [0, 0, 0], [0, 0, 0]
    ]

    for j in range(len(JointName)):
        locs, dms, pmas, angs = [], [], [], []
        for i in range(len(vecNames)):
            loc = cmds.spaceLocator(n=f"{JointName[j]}{vecNames[i]}")
            cmds.setAttr(f"{loc[0]}.tx", vecPos[i][0])
            cmds.setAttr(f"{loc[0]}.ty", vecPos[i][1])
            cmds.setAttr(f"{loc[0]}.tz", vecPos[i][2])
            cmds.setAttr(f"{loc[0]}.localScaleX", 0.01)
            cmds.setAttr(f"{loc[0]}.localScaleY", 0.01)
            cmds.setAttr(f"{loc[0]}.localScaleZ", 0.01)
            locs.append(loc)
        dri = cmds.group(*locs[0:9], n=f"{JointName[j]}_DriGrp")
        cmds.parent(dri, locs[9])
        cmds.setAttr(f"{locs[9][0]}.v", 0)
        for ln in range(8):
            cmds.addAttr(dri, ln=f"{JointName[j]}{vecNames[ln]}", at="float", min=0, max=1, k=1)
        for p in range(10):
            dm = cmds.createNode("decomposeMatrix", n=f"{locs[p][0]}_poseReader_dm")
            cmds.connectAttr(f"{locs[p][0]}.worldMatrix", f"{dm}.inputMatrix")
            dms.append(dm)
            if p != 8:
                pm = cmds.createNode("plusMinusAverage", n=f"{locs[p][0]}_pma")
                cmds.setAttr(f"{pm}.operation", 2)
                pmas.append(pm)
        for k in range(9):
            cmds.connectAttr(f"{dms[9]}.outputTranslate", f"{pmas[k]}.input3D[1]")
        for a in range(9):
            cmds.connectAttr(f"{dms[a]}.outputTranslate", f"{pmas[a]}.input3D[2]")
        for a in range(8):
            ab = cmds.createNode("angleBetween", n=f"{locs[a][0]}_angle")
            cmds.connectAttr(f"{pmas[8]}.output3D", f"{ab}.vector1")
            cmds.connectAttr(f"{pmas[a]}.output3D", f"{ab}.vector2")
            angs.append(ab)

        AllAng.append(angs)
        cmds.delete(cmds.pointConstraint(AllSet[j], locs[9], mo=0))

    cmds.parentConstraint("M_Spine_chest_jnt", f"{JointName[0]}_position", mo=1)
    cmds.parentConstraint(AllJ[0], f"{JointName[1]}_position", mo=1)
    cmds.parentConstraint(AllJ[1], f"{JointName[2]}_position", mo=1)
    cmds.parentConstraint(AllJ[2], f"{JointName[3]}_position", mo=1)
    cmds.parentConstraint("M_Spine_chest_jnt", f"{JointName[4]}_position", mo=1)
    cmds.parentConstraint(AllJ[5], f"{JointName[5]}_position", mo=1)
    cmds.parentConstraint(AllJ[6], f"{JointName[6]}_position", mo=1)
    cmds.parentConstraint(AllJ[7], f"{JointName[7]}_position", mo=1)

    cmds.pointConstraint(AllJ[1], f"{JointName[0]}_direction", mo=0)
    cmds.pointConstraint(AllJ[2], f"{JointName[1]}_direction", mo=0)
    cmds.pointConstraint(AllJ[3], f"{JointName[2]}_direction", mo=0)
    cmds.pointConstraint(AllJ[4], f"{JointName[3]}_direction", mo=0)
    cmds.pointConstraint(AllJ[6], f"{JointName[4]}_direction", mo=0)
    cmds.pointConstraint(AllJ[7], f"{JointName[5]}_direction", mo=0)
    cmds.pointConstraint(AllJ[8], f"{JointName[6]}_direction", mo=0)
    cmds.pointConstraint(AllJ[9], f"{JointName[7]}_direction", mo=0)

    cmds.parent(
        f"{JointName[0]}_position",
        f"{JointName[1]}_position",
        f"{JointName[2]}_position",
        f"{JointName[3]}_position",
        f"{JointName[4]}_position",
        f"{JointName[5]}_position",
        f"{JointName[6]}_position",
        f"{JointName[7]}_position",
        ARISE_DRIVE_GRP
    )
    All_BSname = []
    All_Driver = []
    vec2 = ["_U", "_D", "_F", "_B", "_FU", "_FD", "_BU", "_BD"]

    def append_for(ns_index, jL, jR):
        for vec in range(8):
            All_BSname.append(cmds.duplicate(namestring[ns_index], n=f"{JointName[jL]}{vec2[vec]}"))
            All_BSname.append(cmds.duplicate(namestring[ns_index], n=f"{JointName[jR]}{vec2[vec]}"))
            All_Driver.append(f"{JointName[jL]}_DriGrp.{JointName[jL]}{vecNames[vec]}")
            All_Driver.append(f"{JointName[jR]}_DriGrp.{JointName[jR]}{vecNames[vec]}")

    append_for(1, 0, 4)
    append_for(1, 1, 5)
    append_for(1, 2, 6)
    append_for(1, 3, 7)

    bs_node = f"{namestring[1]}BS"
    if not cmds.objExists(bs_node):
        cmds.blendShape(namestring[1], n=bs_node, foc=True)
    base = cmds.blendShape(bs_node, q=True, weightCount=True) or 0
    for i, bs_target in enumerate(All_BSname):
        target = bs_target[0]
        cmds.blendShape(bs_node, e=True, t=(namestring[1], base + i, target, 1.0))
        cmds.delete(target)

        cmds.setDrivenKeyframe(
            f"{bs_node}.{target}",
            driverValue=0,
            cd=All_Driver[i],
            value=0,
            itt="linear",
            ott="linear"
        )
        cmds.setDrivenKeyframe(
            f"{bs_node}.{target}",
            driverValue=1,
            cd=All_Driver[i],
            value=1,
            itt="linear",
            ott="linear"
        )

    for j in range(8):
        for b in range(8):
            drv_attr = f"{JointName[j]}_DriGrp.{JointName[j]}{vecNames[b]}"
            angle_attr = f"{AllAng[j][b]}.angle"
            if b > 3:
                dv = 45
            else:
                try:
                    dv = cmds.getAttr(f"{AllAng[j][b]}.axisAngle.angle")
                except Exception:
                    dv = 90
            cmds.setDrivenKeyframe(drv_attr, driverValue=dv, cd=angle_attr, value=0, itt="linear", ott="linear")
            cmds.setDrivenKeyframe(drv_attr, driverValue=0, cd=angle_attr, value=1, itt="linear", ott="linear")

def _create_neck_drive_impl(namestring: dict):
    if not cmds.objExists(ARISE_DRIVE_GRP):
        cmds.group(em=True, name=ARISE_DRIVE_GRP)

    jointName = namestring[19]
    vecNames = [
        "_Up", "_Dn", "_Front", "_Back",
        "_FrontUp", "_FrontDn", "_BackUp", "_BackDn",
        "_direction", "_position"
    ]
    locPos = [
        [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1],
        [0, 0.6, 0.6], [0, -0.6, 0.6], [0, 0.6, -0.6], [0, -0.6, -0.6],
        [0, 0, 0], [0, 0, 0]
    ]
    locs, dms, pmas, angs = [], [], [], []

    for i in range(len(vecNames)):
        loc = cmds.spaceLocator(n=f"{jointName}{vecNames[i]}")
        cmds.setAttr(f"{loc[0]}.tx", locPos[i][0])
        cmds.setAttr(f"{loc[0]}.ty", locPos[i][1])
        cmds.setAttr(f"{loc[0]}.tz", locPos[i][2])
        cmds.setAttr(f"{loc[0]}.localScaleX", 0.1)
        cmds.setAttr(f"{loc[0]}.localScaleY", 0.1)
        cmds.setAttr(f"{loc[0]}.localScaleZ", 0.1)
        locs.append(loc)

    dri = cmds.group(*locs[0:9], n=f"{jointName}_DriveGrp")
    cmds.parent(dri, locs[9])
    cmds.setAttr(f"{locs[9][0]}.v", 0)

    for i in range(8):
        cmds.addAttr(dri, ln=f"{jointName}{vecNames[i]}", at="float", min=0, max=1, k=True)
    for p in range(10):
        dm = cmds.createNode("decomposeMatrix", n=f"{locs[p][0]}_poseReader_dm")
        cmds.connectAttr(f"{locs[p][0]}.worldMatrix", f"{dm}.inputMatrix")
        dms.append(dm)
        if p != 8:
            pm = cmds.createNode("plusMinusAverage", n=f"{locs[p][0]}_pma")
            cmds.setAttr(f"{pm}.operation", 2)
            pmas.append(pm)

    for k in range(9):
        cmds.connectAttr(f"{dms[9]}.outputTranslate", f"{pmas[k]}.input3D[1]")
    for a in range(9):
        cmds.connectAttr(f"{dms[a]}.outputTranslate", f"{pmas[a]}.input3D[2]")
    for a in range(8):
        ab = cmds.createNode("angleBetween", n=f"{locs[a][0]}_angle")
        cmds.connectAttr(f"{pmas[8]}.output3D", f"{ab}.vector1")
        cmds.connectAttr(f"{pmas[a]}.output3D", f"{ab}.vector2")
        angs.append(ab)

    cmds.delete(cmds.pointConstraint(jointName, locs[9], mo=False))
    cmds.parentConstraint(namestring[20], f"{jointName}_position", mo=1)
    cmds.pointConstraint(namestring[21], f"{jointName}_direction", mo=0)
    cmds.parent(f"{jointName}_position", ARISE_DRIVE_GRP)

    model = namestring[1]
    bs_node = f"{model}BS"

    if not cmds.objExists(bs_node):
        cmds.blendShape(model, n=bs_node, foc=True)
    base = cmds.blendShape(bs_node, q=True, weightCount=True) or 0
    vec2 = ["_U", "_D", "_F", "_B", "_FU", "_FD", "_BU", "_BD"]
    all_bs, all_drv = [], []

    for i in range(8):
        dup = cmds.duplicate(model, n=f"{jointName}{vec2[i]}", rr=True)[0]
        all_bs.append(dup)
        all_drv.append(f"{jointName}_DriveGrp.{jointName}{vecNames[i]}")
    for i, target in enumerate(all_bs):
        cmds.blendShape(bs_node, e=True, t=(model, base + i, target, 1.0))
        cmds.delete(target)

        cmds.setDrivenKeyframe(
            f"{bs_node}.{target}",
            driverValue=0,
            cd=all_drv[i],
            value=0,
            itt="linear",
            ott="linear"
        )
        cmds.setDrivenKeyframe(
            f"{bs_node}.{target}",
            driverValue=1,
            cd=all_drv[i],
            value=1,
            itt="linear",
            ott="linear"
        )

    for b in range(8):
        dv = 45 if b > 3 else cmds.getAttr(f"{angs[b]}.axisAngle.angle")
        drv_attr = f"{jointName}_DriveGrp.{jointName}{vecNames[b]}"
        angle_attr = f"{angs[b]}.angle"
        cmds.setDrivenKeyframe(drv_attr, driverValue=dv, cd=angle_attr, value=0, itt="linear", ott="linear")
        cmds.setDrivenKeyframe(drv_attr, driverValue=0, cd=angle_attr, value=1, itt="linear", ott="linear")

# QSS THEMES (Cold/Warm/Bright/Dark)
# =========================
COLD_DARK_QSS = """  
* { font-family: "Microsoft Yahei UI", "Segoe UI", "Helvetica Neue"; font-size: 11pt; }  
QWidget { background-color: #0F131A; color: #E6EDF6; }  
QMainWindow, QDialog { background-color: #0D1117; }  
QTabWidget::pane { border: 1px solid #1E2330; border-radius: 10px; background: #0F141C; margin: 8px; }  
QTabBar::tab { background: #131A22; color: #C6D5E4; padding: 10px 16px; border-top-left-radius: 8px; border-top-right-radius: 8px; margin: 3px; min-width: 120px; border: 1px solid transparent; }  
QTabBar::tab:selected { background: #0F1B2A; color: #74D3FF; border: 1px solid #1FB8FF; }  
QTabBar::tab:hover   { color: #AEEBFF; }  
QGroupBox { border: 1px solid #1E2330; border-radius: 10px; background: #0E1620; padding-top: 1.6em; margin-top: 6px; }  
QGroupBox::title { subcontrol-origin: padding; subcontrol-position: top left; left: 10px; padding: 0 8px; color: #8FB9FF; background: #0E1620; }  
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { background: #0D1520; border: 1px solid #243041; border-radius: 6px; padding: 6px; selection-background-color: #25C3FF; selection-color: #0B1016; color: #E6EDF6; }  
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus { border: 1px solid #25C3FF; }  
QListWidget, QTreeWidget, QTableWidget, QAbstractItemView { background: #0D1520; color: #E6EDF6; border: 1px solid #243041; border-radius: 6px; }  
QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected { background: #0F2233; color: #A6E7FF; }  
QPushButton { background-color: #111A24; color: #E6EDF6; border: 1px solid #243041; border-radius: 8px; padding: 8px 14px; }  
QPushButton:hover   { border-color: #25C3FF; color: #AEEBFF; background-color: #0E2030; }  
QPushButton:pressed { background: #0B1621; }  
QPushButton[accent="true"] { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #00D4FF, stop:1 #3B82F6); border: none; color: #0F1419; font-weight: 600; }  
QCheckBox { spacing: 8px; }  
QCheckBox::indicator { width: 16px; height: 16px; }  
QCheckBox::indicator:checked   { image: none; border: 1px solid #25C3FF; background: #25C3FF; border-radius: 3px; }  
QCheckBox::indicator:unchecked { image: none; border: 1px solid #243041; background: #0D1520; border-radius: 3px; }  
QLabel[hint="true"] { color: #9FB2C7; }  
QToolTip { background: #0F141C; color: #E6EDF6; border: 1px solid #243041; padding: 6px; border-radius: 6px; }  
"""

WARM_DARK_QSS = """  
* { font-family: "Microsoft Yahei UI", "Segoe UI", "Helvetica Neue"; font-size: 11pt; }  
QWidget { background-color: #231A12; color: #F4EEE6; }  
QMainWindow, QDialog { background-color: #251D14; }  
QTabWidget::pane { border: 1px solid #3C2D21; border-radius: 10px; background: #2A2118; margin: 8px; }  
QTabBar::tab { background: #2D2319; color: #E4D6C9; padding: 10px 16px; border-top-left-radius: 8px; border-top-right-radius: 8px; margin: 3px; min-width: 120px; border: 1px solid transparent; }  
QTabBar::tab:selected { background: #34271C; color: #FFB464; border: 1px solid #FFB464; }  
QTabBar::tab:hover   { color: #FFC682; }  
QGroupBox { border: 1px solid #3C2D21; border-radius: 10px; background: #281F17; padding-top: 1.6em; margin-top: 6px; }  
QGroupBox::title { subcontrol-origin: padding; subcontrol-position: top left; left: 10px; padding: 0 8px; color: #FFB464; background: #281F17; }  
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { background: #201811; border: 1px solid #4A392B; border-radius: 6px; padding: 6px; selection-background-color: #FFB464; selection-color: #1E140D; color: #F6F1EA; }  
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus { border: 1px solid #FFB464; }  
QListWidget, QTreeWidget, QTableWidget, QAbstractItemView { background: #201811; color: #F4EEE6; border: 1px solid #4A392B; border-radius: 6px; }  
QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected { background: #3A2A1E; color: #FFD59A; }  
QPushButton { background-color: #2C2219; color: #F6F1EA; border: 1px solid #4A392B; border-radius: 8px; padding: 8px 14px; }  
QPushButton:hover   { border-color: #FFB464; color: #FFB464; background-color: #32271D; }  
QPushButton:pressed { background: #2A2118; }  
QPushButton[accent="true"] { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #FFB75E, stop:1 #FF8A3B); border: none; color: #26160A; font-weight: 600; }  
QCheckBox { spacing: 8px; }  
QCheckBox::indicator { width: 16px; height: 16px; }  
QCheckBox::indicator:checked   { image: none; border: 1px solid #FFB464; background: #FFB464; border-radius: 3px; }  
QCheckBox::indicator:unchecked { image: none; border: 1px solid #4A392B; background: #201811; border-radius: 3px; }  
QLabel[hint="true"] { color: #CDAF90; }  
QToolTip { background-color: #2F241A; color: #F4EEE6; border: 1px solid #4A392B; padding: 6px; border-radius: 6px; }

QListWidget#Sidebar {
    background: #1B130D;
    border: 1px solid #3C2D21;
    border-radius: 12px;
    padding: 8px;
}

QListWidget#Sidebar::item {
    color: #D8C4AE;
    padding: 10px 12px;
    border-radius: 8px;
    margin: 2px;
}

QListWidget#Sidebar::item:selected {
    background: #34271C;
    color: #FFB464;
    border-left: 4px solid #FFB464;
    font-weight: 700;
}

QListWidget#Sidebar::item:hover {
    background: #2A2118;
    color: #FFC682;
}

QLabel#PageTitle {
    font-size: 22px;
    font-weight: 700;
    color: #F6F1EA;
    background: transparent;
}

QLabel#PageSubtitle {
    color: #CDAF90;
    background: transparent;
}

QFrame#LeftPanel {
    background: transparent;
    border: none;
}

QSplitter#MainSplitter {
    background: transparent;
}

QSplitter#MainSplitter::handle {
    background-color: #1A120C;
    width: 12px;
    margin: 0px 2px;
    border-left: 1px solid #2E2118;
    border-right: 1px solid #2E2118;
}

QSplitter#MainSplitter::handle:hover {
    background-color: #2A1D13;
    border-left: 1px solid #FFB464;
    border-right: 1px solid #FFB464;
}

QSplitter#MainSplitter::handle:horizontal {
    image: none;
}


QFrame#SidebarInfo {
    background: #1B130D;
    border: 1px solid #3C2D21;
    border-radius: 12px;
}

QLabel#SidebarInfoTitle {
    color: #FFB464;
    font-size: 10pt;
    font-weight: 700;
    background: transparent;
}

QLabel#SidebarInfoValue {
    color: #F6F1EA;
    font-size: 12pt;
    font-weight: 700;
    background: transparent;
}

QLabel#SidebarInfoSmall {
    color: #CDAF90;
    font-size: 9pt;
    background: transparent;
}

QLabel#SidebarVersion {
    color: #7F6A55;
    font-size: 8pt;
    background: transparent;
}

QFrame#SidebarDivider {
    background: #3C2D21;
    max-height: 1px;
    border: none;
}

QFrame#Card {
    background: #281F17;
    border: 1px solid #3C2D21;
    border-radius: 14px;
}

QFrame#Card:hover {
    border: 1px solid #5A422E;
}

QLabel#CardTitle {
    color: #FFB464;
    font-size: 12pt;
    font-weight: 700;
    background: transparent;
}

QLabel#CardSubtitle {
    color: #CDAF90;
    font-size: 8.5pt;
    background: transparent;
}

QListWidget {
    outline: none;
}

QListWidget::item {
    padding: 5px 8px;
    border-radius: 5px;
}

QListWidget::item:hover {
    background: #2E2319;
    color: #FFC682;
}

QListWidget::item:selected {
    background: #3A2A1E;
    color: #FFD59A;
    border-left: 3px solid #FFB464;
}

"""

BRIGHT_AMBER_QSS = """  
* { font-family: "Microsoft Yahei UI", "Segoe UI", "Helvetica Neue"; font-size: 11pt; }  
QWidget { background-color: #F3E6C5; color: #2B1F13; }  
QMainWindow, QDialog { background-color: #F6EACF; }  
QTabWidget::pane { border: 1px solid #D7C2A3; border-radius: 10px; background: #FFF3D9; margin: 8px; }  
QTabBar::tab { background: #FFE9B8; color: #6A4B2A; padding: 10px 16px; border-top-left-radius: 8px; border-top-right-radius: 8px; margin: 3px; min-width: 120px; border: 1px solid transparent; }  
QTabBar::tab:selected { background: #FFE1A1; color: #A04E00; border: 1px solid #FFB648; }  
QTabBar::tab:hover   { color: #C76412; }  
QGroupBox { border: 1px solid #D7C2A3; border-radius: 10px; background: #FFF6DE; padding-top: 1.6em; margin-top: 6px; }  
QGroupBox::title { subcontrol-origin: padding; subcontrol-position: top left; left: 10px; padding: 0 8px; color: #A55800; background: #FFF6DE; }  
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { background: #FFF9EC; border: 1px solid #D7C2A3; border-radius: 6px; padding: 6px; selection-background-color: #FFB648; selection-color: #2B1F13; color: #2B1F13; }  
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus { border: 1px solid #FFB648; }  
QListWidget, QTreeWidget, QTableWidget, QAbstractItemView { background: #FFF9EC; color: #2B1F13; border: 1px solid #D7C2A3; border-radius: 6px; }  
QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected { background: #FFE0A8; color: #2B1F13; }  
QPushButton { background-color: #FFE6B8; color: #3A2A1A; border: 1px solid #D7C2A3; border-radius: 8px; padding: 8px 14px; }  
QPushButton:hover   { border-color: #FFB648; color: #A04E00; background-color: #FFDFA1; }  
QPushButton:pressed { background: #FFD48A; }  
QPushButton[accent="true"] { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #FFB648, stop:1 #FF8A3B); border: none; color: #2B1709; font-weight: 600; }  
QCheckBox { spacing: 8px; color: #2B1F13; }  
QCheckBox::indicator { width: 16px; height: 16px; }  
QCheckBox::indicator:checked   { image: none; border: 1px solid #FFB648; background: #FFB648; border-radius: 3px; }  
QCheckBox::indicator:unchecked { image: none; border: 1px solid #D7C2A3; background: #FFF9EC; border-radius: 3px; }  
QLabel[hint="true"] { color: #8C6A43; }  
QToolTip { background-color: #FFF3D9; color: #2B1F13; border: 1px solid #D7C2A3; padding: 6px; border-radius: 6px; }  
"""

NEUTRAL_DARK_QSS = """  
* { font-family: "Microsoft Yahei UI", "Segoe UI", "Helvetica Neue"; font-size: 11pt; }  
QWidget { background-color: #141414; color: #EAEAEA; }  
QMainWindow, QDialog { background-color: #121212; }  
QTabWidget::pane { border: 1px solid #2A2A2A; border-radius: 10px; background: #161616; margin: 8px; }  
QTabBar::tab { background: #1B1B1B; color: #D8D8D8; padding: 10px 16px; border-top-left-radius: 8px; border-top-right-radius: 8px; margin: 3px; min-width: 120px; border: 1px solid transparent; }  
QTabBar::tab:selected { background: #202020; color: #FFFFFF; border: 1px solid #5A5A5A; }  
QTabBar::tab:hover   { color: #FFFFFF; }  
QGroupBox { border: 1px solid #2A2A2A; border-radius: 10px; background: #181818; padding-top: 1.6em; margin-top: 6px; }  
QGroupBox::title { subcontrol-origin: padding; subcontrol-position: top left; left: 10px; padding: 0 8px; color: #CFCFCF; background: #181818; }  
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { background: #151515; border: 1px solid #3A3A3A; border-radius: 6px; padding: 6px; selection-background-color: #5A9BFF; selection-color: #0E0E0E; color: #EAEAEA; }  
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus { border: 1px solid #5A9BFF; }  
QListWidget, QTreeWidget, QTableWidget, QAbstractItemView { background: #151515; color: #EAEAEA; border: 1px solid #3A3A3A; border-radius: 6px; }  
QListWidget::item:selected, QTreeWidget::item:selected, QTableWidget::item:selected { background: #222222; color: #FFFFFF; }  
QPushButton { background-color: #1C1C1C; color: #EAEAEA; border: 1px solid #3A3A3A; border-radius: 8px; padding: 8px 14px; }  
QPushButton:hover   { border-color: #5A9BFF; color: #FFFFFF; background-color: #202020; }  
QPushButton:pressed { background: #1A1A1A; }  
QPushButton[accent="true"] { background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #5A9BFF, stop:1 #3B82F6); border: none; color: #0E0E0E; font-weight: 600; }  
QCheckBox { spacing: 8px; }  
QCheckBox::indicator { width: 16px; height: 16px; }  
QCheckBox::indicator:checked   { image: none; border: 1px solid #5A9BFF; background: #5A9BFF; border-radius: 3px; }  
QCheckBox::indicator:unchecked { image: none; border: 1px solid #3A3A3A; background: #151515; border-radius: 3px; }  
QLabel[hint="true"] { color: #B5B5B5; }  
QToolTip { background: #161616; color: #EAEAEA; border: 1px solid #3A3A3A; padding: 6px; border-radius: 6px; }  
"""

THEMES = {
    "cold": ("Cold", COLD_DARK_QSS),
    "warm": ("Warm", WARM_DARK_QSS),
    "bright": ("Bright", BRIGHT_AMBER_QSS),
    "dark": ("Dark", NEUTRAL_DARK_QSS),
}

# =========================
# Arise Naming Presets
# =========================

ARISE_DRIVE_GRP = "Grp_Arise_Drive"

ARISE_ARM_JOINTS_L = [
    "L_Arm_base_jnt",
    "L_Arm_root_jnt",
    "L_Arm_mid_jnt",
    "L_Arm_tip_jnt",
]

ARISE_LEG_JOINTS_L = [
    "L_Leg_base_jnt",
    "L_Leg_root_jnt",
    "L_Leg_mid_jnt",
    "L_Leg_tip_jnt",
    "L_Leg_toes_root_jnt",
]

ARISE_BODY_FK_CTRLS_L = [
    "L_Arm_base_ctrl",
    "L_Arm_fk_root_ctrl",
    "L_Arm_fk_mid_ctrl",
    "L_Arm_fk_tip_ctrl",
    "L_Leg_base_ctrl",
    "L_Leg_fk_root_ctrl",
    "L_Leg_fk_mid_ctrl",
    "L_Leg_fk_tip_ctrl",
]

THEME_ORDER = ["cold", "warm", "bright", "dark"]
SETTINGS_ORG = "ArisePoseDriver"
SETTINGS_APP = "NeonUI"
SETTINGS_KEY = "theme_key"


class ThemeManager(QtCore.QObject):
    themeChanged = QtCore.Signal(str)

    def __init__(self, target_window: QtWidgets.QWidget, default_key: str = "warm"):
        QtCore.QObject.__init__(self, target_window)
        self._w = target_window
        self._key = self._load_key() or default_key
        if self._key not in THEMES:
            self._key = "warm"
        self.apply(self._key)

    def apply(self, key: str):
        if key not in THEMES:
            key = "warm"
        _, qss = THEMES[key]
        self._w.setStyleSheet(qss)
        self._key = key
        self._save_key(key)
        self.themeChanged.emit(key)

    def cycle_next(self):
        idx = THEME_ORDER.index(self._key)
        nxt = THEME_ORDER[(idx + 1) % len(THEME_ORDER)]
        self.apply(nxt)

    def current_name(self) -> str:
        return THEMES[self._key][0]

        # persistence

    def _load_key(self) -> str | None:
        try:
            if cmds.optionVar(exists=SETTINGS_KEY):
                v = cmds.optionVar(q=SETTINGS_KEY)
                return str(v)
        except Exception:
            pass
        s = QtCore.QSettings(SETTINGS_ORG, SETTINGS_APP)
        return s.value(SETTINGS_KEY, type=str)

    def _save_key(self, key: str):
        try:
            if cmds.optionVar(exists=SETTINGS_KEY):
                cmds.optionVar(stringValue=(SETTINGS_KEY, key))
            else:
                cmds.optionVar(sv=(SETTINGS_KEY, key))
        except Exception:
            pass
        s = QtCore.QSettings(SETTINGS_ORG, SETTINGS_APP)
        s.setValue(SETTINGS_KEY, key)


def attach_theme_button(parent_window: QtWidgets.QWidget, header_layout: QtWidgets.QLayout) -> ThemeManager:
    tm = ThemeManager(parent_window, default_key="warm")
    btn = QtWidgets.QPushButton(f"Theme: {tm.current_name()}")
    btn.setObjectName("btnThemeSwitcher")
    header_layout.addWidget(btn)

    menu = QtWidgets.QMenu(btn)
    act_map = {}
    for k in THEME_ORDER:
        act = ActionClass(f"{THEMES[k][0]} ({k})", menu)
        menu.addAction(act)
        act_map[act] = k
    btn.setMenu(menu)

    btn.clicked.connect(lambda checked=False: tm.cycle_next())
    menu.triggered.connect(lambda a: tm.apply(act_map[a]))
    tm.themeChanged.connect(lambda k: btn.setText(f"Theme: {THEMES[k][0]}"))
    return tm

class DotSplitterHandle(QtWidgets.QSplitterHandle):
    """Splitter handle with painted dot grip."""

    def __init__(self, orientation, parent):
        QtWidgets.QSplitterHandle.__init__(self, orientation, parent)
        self.setMouseTracking(True)
        self._hover = False

    def enterEvent(self, event):
        self._hover = True
        self.update()
        QtWidgets.QSplitterHandle.enterEvent(self, event)

    def leaveEvent(self, event):
        self._hover = False
        self.update()
        QtWidgets.QSplitterHandle.leaveEvent(self, event)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
        rect = self.rect()
        bg = QtGui.QColor("#2A1D13") if self._hover else QtGui.QColor("#1A120C")
        dot = QtGui.QColor("#FFB464") if self._hover else QtGui.QColor("#6F543A")
        painter.fillRect(rect, bg)

        # Side guide lines
        line_color = QtGui.QColor("#FFB464") if self._hover else QtGui.QColor("#3C2D21")
        painter.setPen(line_color)

        if self.orientation() == QtCore.Qt.Horizontal:
            painter.drawLine(rect.left(), rect.top() + 4, rect.left(), rect.bottom() - 4)
            painter.drawLine(rect.right() - 1, rect.top() + 4, rect.right() - 1, rect.bottom() - 4)

            # Center dot grip
            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(dot)

            cx = rect.center().x()
            y = rect.top() + 14
            while y < rect.bottom() - 14:
                painter.drawEllipse(QtCore.QPointF(cx, y), 1.2, 1.2)
                y += 7

        else:
            painter.drawLine(rect.left() + 4, rect.top(), rect.right() - 4, rect.top())
            painter.drawLine(rect.left() + 4, rect.bottom() - 1, rect.right() - 4, rect.bottom() - 1)

            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(dot)

            cy = rect.center().y()
            x = rect.left() + 14
            while x < rect.right() - 14:
                painter.drawEllipse(QtCore.QPointF(x, cy), 1.2, 1.2)
                x += 7


class DotSplitter(QtWidgets.QSplitter):
    """QSplitter using DotSplitterHandle."""

    def createHandle(self):
        return DotSplitterHandle(self.orientation(), self)

# =========================
# UI
# =========================
class ArisePoseDriverUI(QtWidgets.QDialog):
    WINDOW_TITLE = "Arise Pose Driver — Adieumadam"

    def __init__(self, parent=maya_main_window()):
        QtWidgets.QDialog.__init__(self, parent)
        self.setObjectName("ArisePoseDriverUI")
        self.setWindowTitle(self.WINDOW_TITLE)
        self.setWindowFlags(QtCore.Qt.Window)
        self.setMinimumWidth(880)

        self.ops = AriseSecOps()
        self._field_map = {}  # index -> QLineEdit used to sync namestring values
        self._build_ui()
        self.theme = attach_theme_button(self, self.header_hb)
        # Default theme
        self.theme.apply("warm")

        # Page switching and live rotation refresh
        self._rot_timer = QtCore.QTimer(self)
        self._rot_timer.setInterval(150)
        self._rot_timer.timeout.connect(self._on_rot_timer)
        self._rot_timer.start()

        self.stack.currentChanged.connect(self._on_page_changed)

        self._idx_page_setup = self.stack.indexOf(self.page_load)
        self._idx_page_pose = self.stack.indexOf(self.page_pose)
        self._idx_page_fingers = self.stack.indexOf(self.page_fingers)
        self._idx_page_neck = self.stack.indexOf(self.page_neck)

        # ---------- UI Build ----------

    def closeEvent(self, event):
        """Handle UI close event."""
        global _ui_instance
        if _ui_instance == self:
            _ui_instance = None
        QtWidgets.QDialog.closeEvent(self, event)

    def _refresh_neck_rot(self):
        """Refresh the live neck rotation display."""
        if not hasattr(self, 'le_n_rx') or not hasattr(self, 'ed_neck_ctrl'):
            return
        ctl = self.ed_neck_ctrl.text().strip()
        if not ctl or not cmds.objExists(ctl):
            return
        try:
            rx, ry, rz = cmds.getAttr(f"{ctl}.rotate")[0]
            t0, t1, t2 = f"{rx:.3f}", f"{ry:.3f}", f"{rz:.3f}"
            if self.le_n_rx.text() != t0: self.le_n_rx.setText(t0)
            if self.le_n_ry.text() != t1: self.le_n_ry.setText(t1)
            if self.le_n_rz.text() != t2: self.le_n_rz.setText(t2)
        except:
            pass

    def _selected_finger_joint_left(self):
        """
        Return the corresponding left finger joint from the selected finger target.
        Example target names:
            Thumb1_L
            Index3_L
        """
        item = self.list_finger_targets.currentItem()
        if not item:
            return None
        name = item.text()  # Thumb1_L / Index3_L ...
        base = name.split("_")[0]  # Thumb1
        finger = ''.join([c for c in base if c.isalpha()])  # Thumb
        idx = ''.join([c for c in base if c.isdigit()])  # '1'/'2'/'3'
        edits_map = {
            "Thumb": self.finger_edits["Thumb"],
            "Index": self.finger_edits["Index"],
            "Middle": self.finger_edits["Middle"],
            "Ring": self.finger_edits["Ring"],
            "Pinky": self.finger_edits["Pinky"],
        } if hasattr(self, "finger_edits") else {
            "Thumb": (self.thumb1, self.thumb2, self.thumb3),
            "Index": (self.index1, self.index2, self.index3),
            "Middle": (self.middle1, self.middle2, self.middle3),
            "Ring": (self.ring1, self.ring2, self.ring3),
            "Pinky": (self.pinky1, self.pinky2, self.pinky3),
        }
        triplet = edits_map.get(finger)
        if not triplet:
            return None
        j = {"1": 0, "2": 1, "3": 2}.get(idx, 0)
        return triplet[j].text().strip()

    def _refresh_finger_rot(self):
        """Refresh the live finger rotation display."""
        if not hasattr(self, 'le_f_rx'):
            return
        jnt = self._selected_finger_joint_left()
        if not jnt or not cmds.objExists(jnt):
            return
        try:
            rx, ry, rz = cmds.getAttr(f"{jnt}.rotate")[0]
            t0, t1, t2 = f"{rx:.3f}", f"{ry:.3f}", f"{rz:.3f}"
            if self.le_f_rx.text() != t0: self.le_f_rx.setText(t0)
            if self.le_f_ry.text() != t1: self.le_f_ry.setText(t1)
            if self.le_f_rz.text() != t2: self.le_f_rz.setText(t2)
        except:
            pass

    def _on_page_changed(self, idx):
        """Refresh sidebar info and rotation display when the page changes."""
        self._update_sidebar_info(idx)
        self._on_rot_timer()

    def _update_sidebar_info(self, idx):
        """Refresh the sidebar information panel."""
        module_names = {
            0: "Setup",
            1: "Body Pose",
            2: "Fingers",
            3: "Neck",
        }
        tips = {
            0: "Prepare model, BlendShape and body drive chains.",
            1: "Load FK controllers, select a pose direction, then apply pose.",
            2: "Map left finger joints and update finger pose targets.",
            3: "Build neck drive and update neck pose directions.",
        }
        name = module_names.get(idx, "Setup")
        tip = tips.get(idx, "Ready.")

        if hasattr(self, "sidebar_module_label"):
            self.sidebar_module_label.setText(name)
        if hasattr(self, "sidebar_tip_label"):
            self.sidebar_tip_label.setText(tip)
        if hasattr(self, "sidebar_model_label"):
            model = None
            if hasattr(self, "ed_model"):
                model = self.ed_model.text().strip()
            if model:
                self.sidebar_model_label.setText(f"Model: {model}")
            else:
                self.sidebar_model_label.setText("Model: Not loaded")

    def _on_rot_timer(self):
        if not hasattr(self, "stack"):
            return
        idx = self.stack.currentIndex()

        if idx == getattr(self, "_idx_page_pose", -1):
            self._refresh_pose_rot()
        elif idx == getattr(self, "_idx_page_fingers", -1):
            self._refresh_finger_rot()
        elif idx == getattr(self, "_idx_page_neck", -1):
            self._refresh_neck_rot()

    def _current_pose_ctl_name(self):
        item = self.list_labels.currentItem()
        if not item:
            return None
        label = item.text()
        fk_index_map = {
            "Arm Base": 11,
            "Arm Root": 12,
            "Arm Mid": 13,
            "Arm Tip": 14,
            "Leg Base": 15,
            "Leg Root": 16,
            "Leg Mid": 17,
            "Leg Tip": 18,
        }
        idx = fk_index_map.get(label)
        return self.ops.namestring.get(idx)

    def _refresh_pose_rot(self):
        """Refresh the live body pose rotation display."""
        if not hasattr(self, 'rot_x_display'):
            return
        ctl = self._current_pose_ctl_name()
        if not ctl or not cmds.objExists(ctl):
            return
        try:
            rx, ry, rz = cmds.getAttr(f"{ctl}.rotate")[0]
            t0, t1, t2 = f"{rx:.3f}", f"{ry:.3f}", f"{rz:.3f}"
            if self.rot_x_display.text() != t0: self.rot_x_display.setText(t0)
            if self.rot_y_display.text() != t1: self.rot_y_display.setText(t1)
            if self.rot_z_display.text() != t2: self.rot_z_display.setText(t2)
        except:
            pass

    def _make_card(self, title: str, subtitle: str = ""):
        """Create a modern card container."""
        card = QtWidgets.QFrame(self)
        card.setObjectName("Card")

        outer = QtWidgets.QVBoxLayout(card)
        outer.setContentsMargins(14, 12, 14, 14)
        outer.setSpacing(10)

        title_label = QtWidgets.QLabel(title)
        title_label.setObjectName("CardTitle")
        outer.addWidget(title_label)

        if subtitle:
            subtitle_label = QtWidgets.QLabel(subtitle)
            subtitle_label.setObjectName("CardSubtitle")
            subtitle_label.setWordWrap(True)
            outer.addWidget(subtitle_label)

        return card, outer

    def _build_ui(self):
        self.resize(980, 720)

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(10)

        # Header
        header = QtWidgets.QWidget(self)
        self.header_hb = QtWidgets.QHBoxLayout(header)
        self.header_hb.setContentsMargins(0, 0, 0, 0)
        self.header_hb.setSpacing(8)

        title = QtWidgets.QLabel("Arise Pose Driver")
        title.setStyleSheet("font-size: 18px; font-weight: 700;")

        subtitle = QtWidgets.QLabel("  ·  Corrective shape pose-reader setup for Arise rigs")
        subtitle.setStyleSheet("color:#9FB2C7;")

        title_box = QtWidgets.QHBoxLayout()
        title_box.setContentsMargins(0, 0, 0, 0)
        title_box.addWidget(title)
        title_box.addWidget(subtitle)

        title_wrap = QtWidgets.QWidget()
        title_wrap.setLayout(title_box)

        self.header_hb.addWidget(title_wrap)
        self.header_hb.addStretch(1)

        docs_btn = QtWidgets.QPushButton("Docs")
        docs_btn.setToolTip("Add your own docs link or help callback")
        self.header_hb.addWidget(docs_btn)

        root.addWidget(header)

        # Main body: Sidebar + Stack with draggable splitter
        self.main_splitter = DotSplitter(QtCore.Qt.Horizontal, self)
        self.main_splitter.setObjectName("MainSplitter")
        self.main_splitter.setChildrenCollapsible(False)

        self.main_splitter.setHandleWidth(14)
        root.addWidget(self.main_splitter, 1)

        # Left panel
        self.left_panel = QtWidgets.QFrame(self)
        self.left_panel.setObjectName("LeftPanel")

        left_layout = QtWidgets.QVBoxLayout(self.left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(10)

        # Sidebar navigation
        self.sidebar = QtWidgets.QListWidget(self.left_panel)
        self.sidebar.setObjectName("Sidebar")
        self.sidebar.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.sidebar.setSpacing(4)

        sidebar_items = [
            "Setup",
            "Body Pose",
            "Fingers",
            "Neck",
        ]

        for name in sidebar_items:
            item = QtWidgets.QListWidgetItem(name)
            item.setSizeHint(QtCore.QSize(150, 46))
            self.sidebar.addItem(item)

        left_layout.addWidget(self.sidebar)

        # Sidebar info area
        self.sidebar_info = QtWidgets.QFrame(self.left_panel)
        self.sidebar_info.setObjectName("SidebarInfo")

        info_layout = QtWidgets.QVBoxLayout(self.sidebar_info)
        info_layout.setContentsMargins(12, 12, 12, 12)
        info_layout.setSpacing(8)

        info_title = QtWidgets.QLabel("Current Module")
        info_title.setObjectName("SidebarInfoTitle")

        self.sidebar_module_label = QtWidgets.QLabel("Setup")
        self.sidebar_module_label.setObjectName("SidebarInfoValue")
        self.sidebar_module_label.setWordWrap(True)

        info_divider = QtWidgets.QFrame()
        info_divider.setObjectName("SidebarDivider")
        info_divider.setFrameShape(QtWidgets.QFrame.HLine)
        info_divider.setFrameShadow(QtWidgets.QFrame.Plain)

        info_source = QtWidgets.QLabel("Source")
        info_source.setObjectName("SidebarInfoTitle")

        self.sidebar_model_label = QtWidgets.QLabel("Model: Not loaded")
        self.sidebar_model_label.setObjectName("SidebarInfoSmall")
        self.sidebar_model_label.setWordWrap(True)

        info_tip = QtWidgets.QLabel("Tip")
        info_tip.setObjectName("SidebarInfoTitle")

        self.sidebar_tip_label = QtWidgets.QLabel("Use Selection will pick the current Maya selected object.")
        self.sidebar_tip_label.setObjectName("SidebarInfoSmall")
        self.sidebar_tip_label.setWordWrap(True)

        info_version = QtWidgets.QLabel("Arise Pose Driver v2")
        info_version.setObjectName("SidebarVersion")

        info_layout.addWidget(info_title)
        info_layout.addWidget(self.sidebar_module_label)
        info_layout.addWidget(info_divider)
        info_layout.addWidget(info_source)
        info_layout.addWidget(self.sidebar_model_label)
        info_layout.addSpacing(6)
        info_layout.addWidget(info_tip)
        info_layout.addWidget(self.sidebar_tip_label)
        info_layout.addStretch(1)
        info_layout.addWidget(info_version)

        left_layout.addWidget(self.sidebar_info)

        # Stack pages
        self.stack = QtWidgets.QStackedWidget(self)
        self.stack.setObjectName("MainStack")

        self.main_splitter.addWidget(self.left_panel)
        self.main_splitter.addWidget(self.stack)

        self.main_splitter.setStretchFactor(0, 0)
        self.main_splitter.setStretchFactor(1, 1)
        self.main_splitter.setSizes([180, 760])

        # =========================
        # Page 1: Setup / Load Drive
        # =========================
        self.page_load = QtWidgets.QWidget()
        self.stack.addWidget(self.page_load)

        page1_root = QtWidgets.QVBoxLayout(self.page_load)
        page1_root.setContentsMargins(0, 0, 0, 0)
        page1_root.setSpacing(10)

        page1_title = QtWidgets.QLabel("Setup")
        page1_title.setObjectName("PageTitle")
        page1_sub = QtWidgets.QLabel("Prepare model, BlendShape and body drive chains.")
        page1_sub.setObjectName("PageSubtitle")
        page1_sub.setWordWrap(True)

        page1_root.addWidget(page1_title)
        page1_root.addWidget(page1_sub)

        g1 = QtWidgets.QGridLayout()
        g1.setColumnStretch(0, 1)
        g1.setColumnStretch(1, 1)
        g1.setRowStretch(0, 0)
        g1.setRowStretch(1, 1)
        page1_root.addLayout(g1, 1)

        # Model & BlendShape Card
        box_model, model_card_layout = self._make_card(
            "Model Source",
            "Select the source mesh, then create or load the BlendShape node."
        )
        box_model.setMaximumHeight(220)

        fm = QtWidgets.QGridLayout()
        fm.setColumnStretch(1, 1)
        model_card_layout.addLayout(fm)

        self.ed_model = QtWidgets.QLineEdit()
        self.ed_model.setPlaceholderText("Select mesh...")
        self._bind_edit(self.ed_model, 1)

        btn_pick_model = QtWidgets.QPushButton("Use Selection")
        btn_pick_model.clicked.connect(lambda checked=False: self._pick_into(self.ed_model, 1))

        fm.addWidget(QtWidgets.QLabel("Model:"), 0, 0)
        fm.addWidget(self.ed_model, 0, 1)
        fm.addWidget(btn_pick_model, 0, 2)

        action_row = QtWidgets.QHBoxLayout()
        action_row.setSpacing(8)
        model_card_layout.addLayout(action_row)

        btn_create_bs = QtWidgets.QPushButton("Create BlendShape")
        btn_create_bs.setProperty("accent", True)

        btn_rename_bs = QtWidgets.QPushButton("Load / Rename BS")
        btn_transfer = QtWidgets.QPushButton("Transfer Targets")

        action_row.addWidget(btn_create_bs)
        action_row.addWidget(btn_rename_bs)
        action_row.addWidget(btn_transfer)

        btn_create_bs.clicked.connect(self.ops.create_blendshape)
        btn_rename_bs.clicked.connect(self.ops.rename_blendshape)
        btn_transfer.clicked.connect(self.ops.transfer_selected_targets)

        # Arm Card
        box_arm, arm_card_layout = self._make_card(
            "Left Arm Chain",
            "Create arm pose-reader drive from the left chain."
        )

        la = QtWidgets.QGridLayout()
        la.setColumnStretch(1, 1)
        arm_card_layout.addLayout(la)

        self.arm_edits = []
        labels_arm = ["Arm Base", "Arm Root", "Arm Mid", "Arm Tip"]

        for i, lab in enumerate(labels_arm):
            ed = QtWidgets.QLineEdit(ARISE_ARM_JOINTS_L[i])
            ed.setPlaceholderText(f"Select {lab}...")
            idx = 2 + i
            self._bind_edit(ed, idx)
            self.arm_edits.append(ed)

            btn = QtWidgets.QPushButton("↙")
            btn.setFixedWidth(42)
            btn.setToolTip("Use current Maya selection")
            btn.clicked.connect(lambda checked=False, e=ed, ii=idx: self._pick_into(e, ii))

            la.addWidget(QtWidgets.QLabel(f"{lab}:"), i, 0)
            la.addWidget(ed, i, 1)
            la.addWidget(btn, i, 2)

        btn_arm = QtWidgets.QPushButton("Build Arm Drive")
        btn_arm.setProperty("accent", True)
        arm_card_layout.addWidget(btn_arm)
        btn_arm.clicked.connect(self.ops.create_arm_drive)

        # Leg Card
        box_leg, leg_card_layout = self._make_card(
            "Left Leg Chain",
            "Create leg pose-reader drive from the left chain."
        )

        ll = QtWidgets.QGridLayout()
        ll.setColumnStretch(1, 1)
        leg_card_layout.addLayout(ll)

        self.leg_edits = []
        labels_leg = ["Leg Base", "Leg Root", "Leg Mid", "Leg Tip", "Leg Toes Root"]

        for i, lab in enumerate(labels_leg):
            ed = QtWidgets.QLineEdit(ARISE_LEG_JOINTS_L[i])
            ed.setPlaceholderText(f"Select {lab}...")
            idx = 6 + i
            self._bind_edit(ed, idx)
            self.leg_edits.append(ed)

            btn = QtWidgets.QPushButton("↙")
            btn.setFixedWidth(42)
            btn.setToolTip("Use current Maya selection")
            btn.clicked.connect(lambda checked=False, e=ed, ii=idx: self._pick_into(e, ii))

            ll.addWidget(QtWidgets.QLabel(f"{lab}:"), i, 0)
            ll.addWidget(ed, i, 1)
            ll.addWidget(btn, i, 2)

        btn_leg = QtWidgets.QPushButton("Build Leg Drive")
        btn_leg.setProperty("accent", True)
        leg_card_layout.addWidget(btn_leg)
        btn_leg.clicked.connect(self.ops.create_leg_drive)

        g1.addWidget(box_model, 0, 0, 1, 2)
        g1.addWidget(box_arm, 1, 0)
        g1.addWidget(box_leg, 1, 1)

        # =========================
        # Page 2: Body Pose
        # =========================
        self.page_pose = QtWidgets.QWidget()
        self.stack.addWidget(self.page_pose)

        page2_root = QtWidgets.QVBoxLayout(self.page_pose)
        page2_root.setContentsMargins(0, 0, 0, 0)
        page2_root.setSpacing(10)

        page2_title = QtWidgets.QLabel("Body Pose")
        page2_title.setObjectName("PageTitle")
        page2_sub = QtWidgets.QLabel("Load FK controllers, choose a pose direction, then save the current pose.")
        page2_sub.setObjectName("PageSubtitle")
        page2_sub.setWordWrap(True)

        page2_root.addWidget(page2_title)
        page2_root.addWidget(page2_sub)

        g2 = QtWidgets.QGridLayout()
        page2_root.addLayout(g2, 1)

        box_fk, fk_card_layout = self._make_card(
            "Source FK Controllers",
            "Load left-side FK controllers for pose update."
        )

        fk = QtWidgets.QGridLayout()
        fk.setColumnStretch(1, 1)
        fk_card_layout.addLayout(fk)

        self.fk_labels = ["Arm Base", "Arm Root", "Arm Mid", "Arm Tip", "Leg Base", "Leg Root", "Leg Mid", "Leg Tip"]
        self.fk_edits = []

        for i, lab in enumerate(self.fk_labels):
            ed = QtWidgets.QLineEdit(ARISE_BODY_FK_CTRLS_L[i])
            ed.setPlaceholderText("Select controller...")
            idx = 11 + i
            self._bind_edit(ed, idx)

            btn = QtWidgets.QPushButton("↙")
            btn.setFixedWidth(42)
            btn.setToolTip("Use current Maya selection")
            btn.clicked.connect(lambda checked=False, e=ed, ii=idx: self._pick_into(e, ii))

            fk.addWidget(QtWidgets.QLabel(f"{lab}:"), i, 0)
            fk.addWidget(ed, i, 1)
            fk.addWidget(btn, i, 2)

            self.fk_edits.append(ed)

        box_up, up_card_layout = self._make_card(
            "Pose Direction",
            "Choose a body part and one pose direction."
        )

        up = QtWidgets.QGridLayout()
        up.setColumnStretch(0, 1)
        up.setColumnStretch(1, 1)
        up_card_layout.addLayout(up)

        self.list_labels = QtWidgets.QListWidget()
        self.list_labels.addItems(self.fk_labels)

        self.list_bs_targets = QtWidgets.QListWidget()

        up.addWidget(self.list_labels, 0, 0)
        up.addWidget(self.list_bs_targets, 0, 1)

        self.list_labels.currentTextChanged.connect(self._on_limb_selection_changed)
        self.list_labels.itemSelectionChanged.connect(self._update_rotation_display)

        self.list_labels.setCurrentRow(0)
        if self.list_labels.currentItem():
            self._on_limb_selection_changed(self.list_labels.currentItem().text())

        rot_layout = QtWidgets.QGridLayout()

        self.rot_x_display = QtWidgets.QLineEdit("0.0")
        self.rot_x_display.setReadOnly(True)

        self.rot_y_display = QtWidgets.QLineEdit("0.0")
        self.rot_y_display.setReadOnly(True)

        self.rot_z_display = QtWidgets.QLineEdit("0.0")
        self.rot_z_display.setReadOnly(True)

        rot_layout.addWidget(QtWidgets.QLabel("Rotate X:"), 0, 0)
        rot_layout.addWidget(self.rot_x_display, 0, 1)
        rot_layout.addWidget(QtWidgets.QLabel("Rotate Y:"), 1, 0)
        rot_layout.addWidget(self.rot_y_display, 1, 1)
        rot_layout.addWidget(QtWidgets.QLabel("Rotate Z:"), 2, 0)
        rot_layout.addWidget(self.rot_z_display, 2, 1)

        up.addLayout(rot_layout, 1, 0, 1, 1)

        self.ck_mirror = QtWidgets.QCheckBox("Mirror")
        up.addWidget(self.ck_mirror, 1, 1)

        btn_apply_up = QtWidgets.QPushButton("Apply Body Pose")
        btn_apply_up.setProperty("accent", True)
        btn_apply_up.clicked.connect(lambda checked=False: self._on_apply_update_pose())
        up.addWidget(btn_apply_up, 2, 0, 1, 2)

        hint_label = QtWidgets.QLabel("Hint: Select a body part first, then choose a direction target. "
                                      "Load the left FK controller before applying the pose.")
        hint_label.setProperty("hint", True)
        hint_label.setWordWrap(True)
        up.addWidget(hint_label, 3, 0, 1, 2)

        g2.addWidget(box_fk, 0, 0)
        g2.addWidget(box_up, 0, 1)
        g2.setColumnStretch(0, 1)
        g2.setColumnStretch(1, 1)

        # =========================
        # Page 3: Fingers
        # =========================
        self.page_fingers = QtWidgets.QWidget()
        self.stack.addWidget(self.page_fingers)

        page3_root = QtWidgets.QVBoxLayout(self.page_fingers)
        page3_root.setContentsMargins(0, 0, 0, 0)
        page3_root.setSpacing(10)

        page3_title = QtWidgets.QLabel("Fingers")
        page3_title.setObjectName("PageTitle")
        page3_sub = QtWidgets.QLabel("Map left finger joints, build finger drive, and update finger poses.")
        page3_sub.setObjectName("PageSubtitle")
        page3_sub.setWordWrap(True)

        page3_root.addWidget(page3_title)
        page3_root.addWidget(page3_sub)

        g3 = QtWidgets.QGridLayout()
        page3_root.addLayout(g3, 1)

        box_fj, fj_card_layout = self._make_card(
            "Finger Joints Left",
            "Assign left finger joints. Right-side behavior follows the existing Arise rig logic."
        )

        fj = QtWidgets.QGridLayout()
        fj.setColumnStretch(1, 1)
        fj_card_layout.addLayout(fj)

        self.finger_order = ["Thumb", "Index", "Middle", "Ring", "Pinky"]
        self.finger_edits = {}

        self.default_finger_joints = self.ops.finger_bs_to_joint_map_left()

        default_map = {
            "Thumb1_L": "Thumb_j1", "Thumb2_L": "Thumb_j2", "Thumb3_L": "Thumb_j3",
            "Index1_L": "Index_j1", "Index2_L": "Index_j2", "Index3_L": "Index_j3",
            "Middle1_L": "Middle_j1", "Middle2_L": "Middle_j2", "Middle3_L": "Middle_j3",
            "Ring1_L": "Ring_j1", "Ring2_L": "Ring_j2", "Ring3_L": "Ring_j3",
            "Pinky1_L": "Pinky_j1", "Pinky2_L": "Pinky_j2", "Pinky3_L": "Pinky_j3",
        }

        rev_default_map = {v: k for k, v in default_map.items()}

        row = 0
        for key in self.finger_order:
            j1_name = self.default_finger_joints.get(rev_default_map.get(f"{key}_j1"))
            j2_name = self.default_finger_joints.get(rev_default_map.get(f"{key}_j2"))
            j3_name = self.default_finger_joints.get(rev_default_map.get(f"{key}_j3"))

            e1 = QtWidgets.QLineEdit(j1_name or "")
            e2 = QtWidgets.QLineEdit(j2_name or "")
            e3 = QtWidgets.QLineEdit(j3_name or "")

            b1 = QtWidgets.QPushButton("↙")
            b2 = QtWidgets.QPushButton("↙")
            b3 = QtWidgets.QPushButton("↙")

            for b in (b1, b2, b3):
                b.setFixedWidth(42)
                b.setToolTip("Use current Maya selection")

            b1.clicked.connect(lambda checked=False, e=e1: self._pick_simple(e))
            b2.clicked.connect(lambda checked=False, e=e2: self._pick_simple(e))
            b3.clicked.connect(lambda checked=False, e=e3: self._pick_simple(e))

            fj.addWidget(QtWidgets.QLabel(f"{key} j1:"), row, 0)
            fj.addWidget(e1, row, 1)
            fj.addWidget(b1, row, 2)

            fj.addWidget(QtWidgets.QLabel(f"{key} j2:"), row + 1, 0)
            fj.addWidget(e2, row + 1, 1)
            fj.addWidget(b2, row + 1, 2)

            fj.addWidget(QtWidgets.QLabel(f"{key} j3:"), row + 2, 0)
            fj.addWidget(e3, row + 2, 1)
            fj.addWidget(b3, row + 2, 2)

            self.finger_edits[key] = (e1, e2, e3)
            row += 3

        btn_fingers = QtWidgets.QPushButton("Build Fingers Drive")
        btn_fingers.setProperty("accent", True)
        btn_fingers.clicked.connect(lambda checked=False: self._on_create_fingers())
        fj.addWidget(btn_fingers, row, 0, 1, 3)

        box_upf, upf_card_layout = self._make_card(
            "Finger Pose",
            "Select a finger target and apply the current pose."
        )

        upf = QtWidgets.QGridLayout()
        upf.setColumnStretch(0, 1)
        upf.setColumnStretch(1, 1)
        upf_card_layout.addLayout(upf)

        self.list_finger_groups = QtWidgets.QListWidget()
        self.list_finger_groups.addItems(["Thumb", "Index", "Middle", "Ring", "Pinky"])
        upf.addWidget(self.list_finger_groups, 0, 0)

        self.list_finger_targets = QtWidgets.QListWidget()
        upf.addWidget(self.list_finger_targets, 0, 1)

        self.list_finger_groups.currentTextChanged.connect(self._on_finger_group_changed)
        self.list_finger_groups.setCurrentRow(0)

        self.list_finger_targets.currentTextChanged.connect(lambda _=None: self._refresh_finger_rot())

        self.ck_finger_mirror = QtWidgets.QCheckBox("Mirror")
        upf.addWidget(self.ck_finger_mirror, 1, 1)

        btn_update_finger = QtWidgets.QPushButton("Apply Finger Pose")
        btn_update_finger.setProperty("accent", True)
        btn_update_finger.clicked.connect(lambda checked=False: self._on_update_pose_finger())
        upf.addWidget(btn_update_finger, 2, 1)

        self.le_f_rx = QtWidgets.QLineEdit()
        self.le_f_rx.setReadOnly(True)

        self.le_f_ry = QtWidgets.QLineEdit()
        self.le_f_ry.setReadOnly(True)

        self.le_f_rz = QtWidgets.QLineEdit()
        self.le_f_rz.setReadOnly(True)

        form_frot = QtWidgets.QFormLayout()
        form_frot.addRow("Rotate X:", self.le_f_rx)
        form_frot.addRow("Rotate Y:", self.le_f_ry)
        form_frot.addRow("Rotate Z:", self.le_f_rz)

        upf.addLayout(form_frot, 3, 1)

        g3.addWidget(box_fj, 0, 0)
        g3.addWidget(box_upf, 0, 1)
        g3.setColumnStretch(0, 1)
        g3.setColumnStretch(1, 1)

        # =========================
        # Page 4: Neck
        # =========================
        self.page_neck = QtWidgets.QWidget()
        self.stack.addWidget(self.page_neck)

        page4_root = QtWidgets.QVBoxLayout(self.page_neck)
        page4_root.setContentsMargins(0, 0, 0, 0)
        page4_root.setSpacing(10)

        page4_title = QtWidgets.QLabel("Neck")
        page4_title.setObjectName("PageTitle")
        page4_sub = QtWidgets.QLabel("Build neck drive and update neck pose directions.")
        page4_sub.setObjectName("PageSubtitle")
        page4_sub.setWordWrap(True)

        page4_root.addWidget(page4_title)
        page4_root.addWidget(page4_sub)

        g4 = QtWidgets.QGridLayout()
        page4_root.addLayout(g4, 1)

        box_neck, neck_card_layout = self._make_card(
            "Neck Joints",
            "Assign neck joint, parent reference and child direction target."
        )

        ln = QtWidgets.QGridLayout()
        ln.setColumnStretch(1, 1)
        neck_card_layout.addLayout(ln)

        self.ed_neck_sel = QtWidgets.QLineEdit()
        self._bind_edit(self.ed_neck_sel, 19)

        self.ed_neck_parent = QtWidgets.QLineEdit()
        self._bind_edit(self.ed_neck_parent, 20)

        self.ed_neck_child = QtWidgets.QLineEdit()
        self._bind_edit(self.ed_neck_child, 21)

        btn_pick_sel = QtWidgets.QPushButton("↙")
        btn_pick_parent = QtWidgets.QPushButton("↙")
        btn_pick_child = QtWidgets.QPushButton("↙")

        for b in (btn_pick_sel, btn_pick_parent, btn_pick_child):
            b.setFixedWidth(42)
            b.setToolTip("Use current Maya selection")

        btn_pick_sel.clicked.connect(lambda checked=False: self._pick_into(self.ed_neck_sel, 19))
        btn_pick_parent.clicked.connect(lambda checked=False: self._pick_into(self.ed_neck_parent, 20))
        btn_pick_child.clicked.connect(lambda checked=False: self._pick_into(self.ed_neck_child, 21))

        ln.addWidget(QtWidgets.QLabel("Select Joint:"), 0, 0)
        ln.addWidget(self.ed_neck_sel, 0, 1)
        ln.addWidget(btn_pick_sel, 0, 2)

        ln.addWidget(QtWidgets.QLabel("Parent:"), 1, 0)
        ln.addWidget(self.ed_neck_parent, 1, 1)
        ln.addWidget(btn_pick_parent, 1, 2)

        ln.addWidget(QtWidgets.QLabel("Child:"), 2, 0)
        ln.addWidget(self.ed_neck_child, 2, 1)
        ln.addWidget(btn_pick_child, 2, 2)

        btn_create_neck = QtWidgets.QPushButton("Build Neck Drive")
        btn_create_neck.setProperty("accent", True)
        btn_create_neck.clicked.connect(lambda checked=False: self.ops.create_neck_drive())
        ln.addWidget(btn_create_neck, 3, 0, 1, 3)

        box_neck_ctrl, neck_ctrl_card_layout = self._make_card(
            "Neck FK Controller",
            "Load the FK controller used for neck pose update."
        )

        lnc = QtWidgets.QGridLayout()
        lnc.setColumnStretch(1, 1)
        neck_ctrl_card_layout.addLayout(lnc)

        self.ed_neck_ctrl = QtWidgets.QLineEdit()
        self._bind_edit(self.ed_neck_ctrl, 22)

        btn_pick_ctrl = QtWidgets.QPushButton("↙")
        btn_pick_ctrl.setFixedWidth(42)
        btn_pick_ctrl.setToolTip("Use current Maya selection")
        btn_pick_ctrl.clicked.connect(lambda checked=False: self._pick_into(self.ed_neck_ctrl, 22))

        lnc.addWidget(QtWidgets.QLabel("FK Controller:"), 0, 0)
        lnc.addWidget(self.ed_neck_ctrl, 0, 1)
        lnc.addWidget(btn_pick_ctrl, 0, 2)

        box_up_neck, neck_pose_card_layout = self._make_card(
            "Neck Pose Direction",
            "Select a neck pose direction and apply the current controller pose."
        )

        upn = QtWidgets.QGridLayout()
        upn.setColumnStretch(0, 1)
        neck_pose_card_layout.addLayout(upn)

        upn.addWidget(QtWidgets.QLabel("Pose Direction:"), 0, 0)

        self.list_neck_targets = QtWidgets.QListWidget()
        upn.addWidget(self.list_neck_targets, 1, 0, 3, 1)

        btn_update_neck = QtWidgets.QPushButton("Apply Neck Pose")
        btn_update_neck.setProperty("accent", True)
        btn_update_neck.clicked.connect(lambda checked=False: self._on_update_pose_neck())
        upn.addWidget(btn_update_neck, 4, 0)

        self.ed_neck_sel.textChanged.connect(self._on_neck_joint_changed)

        self.le_n_rx = QtWidgets.QLineEdit()
        self.le_n_rx.setReadOnly(True)

        self.le_n_ry = QtWidgets.QLineEdit()
        self.le_n_ry.setReadOnly(True)

        self.le_n_rz = QtWidgets.QLineEdit()
        self.le_n_rz.setReadOnly(True)

        form_nrot = QtWidgets.QFormLayout()
        form_nrot.addRow("Rotate X:", self.le_n_rx)
        form_nrot.addRow("Rotate Y:", self.le_n_ry)
        form_nrot.addRow("Rotate Z:", self.le_n_rz)

        g4.addWidget(box_neck, 0, 0)
        g4.addWidget(box_neck_ctrl, 1, 0)
        g4.addWidget(box_up_neck, 2, 0)
        g4.addLayout(form_nrot, 3, 0)

        # Sidebar connection
        self.sidebar.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.sidebar.setCurrentRow(0)

    # ---------- Event Handlers ----------

    def _on_finger_group_changed(self, group: str):
        """Refresh the finger target list when the finger group changes."""
        if not hasattr(self, "list_finger_targets"):
            return
        mapping = {
            "Thumb": ["Thumb1_L", "Thumb2_L", "Thumb3_L"],
            "Index": ["Index1_L", "Index2_L", "Index3_L"],
            "Middle": ["Middle1_L", "Middle2_L", "Middle3_L"],
            "Ring": ["Ring1_L", "Ring2_L", "Ring3_L"],
            "Pinky": ["Pinky1_L", "Pinky2_L", "Pinky3_L"],
        }
        if not group or group not in mapping:
            all_targets = []
            for targets in mapping.values():
                all_targets.extend(targets)

            self.list_finger_targets.clear()
            self.list_finger_targets.addItems(all_targets)
            return

        self.list_finger_targets.clear()
        self.list_finger_targets.addItems(mapping[group])

    def _update_rotation_display(self):
        """Update the body pose rotation display when the selected body part changes."""
        if not hasattr(self, "rot_x_display") or not hasattr(self, "rot_y_display") or not hasattr(self, "rot_z_display"):
            return
        sel_items = self.list_labels.selectedItems()
        if not sel_items:
            self.rot_x_display.setText("0.0")
            self.rot_y_display.setText("0.0")
            self.rot_z_display.setText("0.0")
            return

        label = sel_items[0].text()
        fk_index_map = {
            "Arm Base": 11,
            "Arm Root": 12,
            "Arm Mid": 13,
            "Arm Tip": 14,
            "Leg Base": 15,
            "Leg Root": 16,
            "Leg Mid": 17,
            "Leg Tip": 18,
        }

        idx = fk_index_map.get(label)
        ctl = self.ops.namestring.get(idx)

        if ctl and cmds.objExists(ctl):
            try:
                rx = cmds.getAttr(f"{ctl}.rotateX")
                ry = cmds.getAttr(f"{ctl}.rotateY")
                rz = cmds.getAttr(f"{ctl}.rotateZ")
                self.rot_x_display.setText(f"{rx:.3f}")
                self.rot_y_display.setText(f"{ry:.3f}")
                self.rot_z_display.setText(f"{rz:.3f}")
            except Exception:
                self.rot_x_display.setText("0.0")
                self.rot_y_display.setText("0.0")
                self.rot_z_display.setText("0.0")
        else:
            self.rot_x_display.setText("N/A")
            self.rot_y_display.setText("N/A")
            self.rot_z_display.setText("N/A")

    def _bind_edit(self, edit: QtWidgets.QLineEdit, index: int):
        """Bind a QLineEdit to namestring[index]."""
        self._field_map[index] = edit
        edit.textChanged.connect(lambda txt: self._sync_namestring(index, txt))
        self._sync_namestring(index, edit.text())

    def _sync_namestring(self, index: int, text: str):
        """Sync QLineEdit text to ops.namestring."""
        clean_text = text.strip()
        self.ops.namestring[index] = clean_text if clean_text else None

        if index == 1 and hasattr(self, "sidebar_model_label"):
            if clean_text:
                self.sidebar_model_label.setText(f"Model: {clean_text}")
            else:
                self.sidebar_model_label.setText("Model: Not loaded")

    def _pick_simple(self, edit: QtWidgets.QLineEdit, *_, **__):
        """Set a QLineEdit from the current Maya selection."""
        sel = cmds.ls(sl=True)
        if sel:
            edit.setText(sel[0])

    def _pick_into(self, edit: QtWidgets.QLineEdit, index: int, *_, **__):
        """Set a QLineEdit and namestring[index] from the current Maya selection."""
        sel = cmds.ls(sl=True)
        if not sel:
            info_msg("Please select an object first.")
            return

        edit.setText(sel[0])
        self.ops.namestring[index] = sel[0]

    def _on_neck_joint_changed(self, joint_name: str):
        """Refresh neck pose direction targets when the neck joint changes."""
        if not joint_name or not joint_name.strip():
            self.list_neck_targets.clear()
            return
        self.list_neck_targets.clear()
        directions = ["_Up", "_Dn", "_Front", "_Back", "_FrontUp", "_FrontDn", "_BackUp", "_BackDn"]
        joint_clean = joint_name.strip()
        neck_targets = [f"{joint_clean}{direction}" for direction in directions]

        self.list_neck_targets.addItems(neck_targets)

    def _on_limb_selection_changed(self, limb_name: str):
        """Refresh body pose direction targets when the selected body part changes."""
        if not limb_name:
            return
        self.list_bs_targets.clear()
        directions = ["_Up", "_Dn", "_Front", "_Back", "_FrontUp", "_FrontDn", "_BackUp", "_BackDn"]
        arise_limb_to_joint = {
            "Arm Base": "L_Arm_base_jnt",
            "Arm Root": "L_Arm_root_jnt",
            "Arm Mid": "L_Arm_mid_jnt",
            "Arm Tip": "L_Arm_tip_jnt",
            "Leg Base": "L_Leg_base_jnt",
            "Leg Root": "L_Leg_root_jnt",
            "Leg Mid": "L_Leg_mid_jnt",
            "Leg Tip": "L_Leg_tip_jnt",
        }

        joint_name = arise_limb_to_joint.get(limb_name)
        if not joint_name:
            return

        targets = [f"{joint_name}{direction}" for direction in directions]
        self.list_bs_targets.addItems(targets)

    def _on_apply_update_pose(self):
        """Apply body pose update."""
        try:
            sel_targets = self.list_bs_targets.selectedItems()
            if not sel_targets:
                raise RuntimeError("Please select a pose direction target.")
            target_attr = sel_targets[0].text()
            mirror = self.ck_mirror.isChecked()
            current_item = self.list_labels.currentItem()
            if not current_item:
                raise RuntimeError("Please select a body part first.")
            limb_name = current_item.text()
            self.ops.update_pose_joint(limb_name, target_attr, mirror)

        except Exception as e:
            info_msg(f"UpdatePose error: {e}")

    def _on_create_fingers(self):
        """Create finger drive setup."""
        try:
            triplets = {}

            for key in self.finger_order:
                e1, e2, e3 = self.finger_edits[key]
                j1, j2, j3 = e1.text().strip(), e2.text().strip(), e3.text().strip()
                if not (j1 and j2 and j3):
                    raise RuntimeError(f"All three joints are required for {key}.")
                triplets[key] = (j1, j2, j3)

            self.ops.create_fingers_drive(triplets)

        except Exception as e:
            info_msg(f"Finger drive error: {e}")

    def _on_update_pose_finger(self):
        """Apply finger pose update."""
        try:
            sel_items = self.list_finger_targets.selectedItems()
            if not sel_items:
                raise RuntimeError("Please select a finger target.")
            bs_name = sel_items[0].text()
            mirror = self.ck_finger_mirror.isChecked()
            self.ops.update_pose_finger(bs_name, mirror)

        except Exception as e:
            info_msg(f"Finger UpdatePose error: {e}")

    def _on_update_pose_neck(self):
        """Apply neck pose update."""
        try:
            sel_items = self.list_neck_targets.selectedItems()
            if not sel_items:
                raise RuntimeError("Please select a neck pose direction target.")
            target_attr = sel_items[0].text().strip()
            self.ops.update_pose_neck(target_attr)

        except Exception as e:
            info_msg(f"Neck UpdatePose error: {e}")


# =========================
# Window Management
# =========================
_ui_instance = None

def show_ui():
    """Show the UI as a single-instance window."""
    window_name = "ArisePoseDriverUIWindow"

    try:
        if cmds.window(window_name, exists=True):
            cmds.deleteUI(window_name, window=True)
    except Exception:
        pass

    global _ui_instance

    try:
        app = QtWidgets.QApplication.instance()
        for widget in app.topLevelWidgets():
            if hasattr(widget, "objectName"):
                is_same_object = widget.objectName() == "ArisePoseDriverUI"
                is_same_title = widget.windowTitle() == "Arise Pose Driver — Adieumadam"

                if is_same_object or is_same_title:
                    try:
                        widget.close()
                    except Exception:
                        pass

                    try:
                        widget.deleteLater()
                    except Exception:
                        pass

    except Exception:
        pass

    if _ui_instance:
        try:
            _ui_instance.close()
            _ui_instance.deleteLater()
        except Exception:
            pass

    _ui_instance = None
    QtWidgets.QApplication.processEvents()

    try:
        _ui_instance = ArisePoseDriverUI()
        _ui_instance.setObjectName("ArisePoseDriverUI")

        try:
            maya_main = maya_main_window()
            if maya_main:
                _ui_instance.setParent(maya_main)
        except Exception:
            pass

        _ui_instance.setWindowFlags(QtCore.Qt.Window)
        _ui_instance.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        _ui_instance.show()
        _ui_instance.raise_()
        _ui_instance.activateWindow()

        return _ui_instance

    except Exception as e:
        import traceback
        traceback.print_exc()
        cmds.warning(f"UI launch failed: {e}")

def close_ui():
    """Close the UI."""
    global _ui_instance

    if _ui_instance:
        try:
            _ui_instance.close()
        except Exception:
            pass
        finally:
            _ui_instance = None

if __name__ == "__main__":
    show_ui()
